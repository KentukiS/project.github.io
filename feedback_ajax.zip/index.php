<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"  type="text/javascript"></script>
	
</head>
<body>
	<br/>
	<div class="messages"></div>
	<br/>
	<label>Ваше имя:</label><br/>
	<input type="text" id="user_name" value="" /><br/>
	
	<label>Ваш телефон:</label><br/>
	<input type="text" id="user_contact" value="" /><br/>
	

	
	<br/>
	<input type="button" value="Отправить" id="btn_submit" />		


	<script type="text/javascript" src="java.js"></script>
</body>
</html>