$(document).ready(function(){
			$('#btn_submit').click(function(){
				// собираем данные с формы
				var user_name 	 = $('#user_name').val();
				var user_email 	 = $('#user_contact').val();
				
				// отправляем данные
				$.ajax({
					url: "action.php", // куда отправляем
					type: "post", // метод передачи
					dataType: "json", // тип передачи данных
					data: { // что отправляем
						"user_name": 	user_name,
						"user_contact": 	user_email,
						
					},
					// после получения ответа сервера
					success: function(data){
						$('.messages').html(data.result); // выводим ответ сервера
					}
				});
			});
		});


