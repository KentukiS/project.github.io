<?php
	$msg_box = ""; // в этой переменной будем хранить сообщения формы
	$errors = array(); // контейнер для ошибок
	// проверяем корректность полей
	if($_POST['user_name'] == "") 	 $errors[] = "Поле 'Ваше имя' не заполнено!";
    if(!preg_match("/^[0-9]{9,10}+$/", $_POST['user_contact'])) $errors[] = "Телефон написан в неверном формате" ;


	// если форма без ошибок
	if(empty($errors)){		

		// собираем данные из формы
		$message  = "Имя пользователя: " . $_POST['user_name'] . "<br/>";
		$message .= "Телефон пользователя: " . $_POST['user_contact'] . "<br/>";
	
		send_mail($message); // функция вывода сообщения об успехе
		// выведем сообщение об успехе
		$msg_box = "<span style='color: green;'>Сообщение успешно отправлено!</span>";
	}		
	


	else{

		// если были ошибки, то выводим их
		$msg_box = "";
		foreach($errors as $one_error){
			$msg_box .= "<span style='color: red;'>$one_error</span><br/>";
		}
	}




	// делаем ответ на клиентскую часть
	echo json_encode(array(
		'result' => $msg_box
	));
	
	
	function send_mail($message){
	}
	
